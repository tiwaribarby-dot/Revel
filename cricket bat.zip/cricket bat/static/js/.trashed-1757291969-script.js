
// Global variables
let cartCount = 0;
let currentQuizStep = 0;
let quizAnswers = {};

// Utility Functions
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => notification.classList.add('show'), 100);
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => document.body.removeChild(notification), 300);
    }, 3000);
}

function updateCartCount(count) {
    cartCount = count;
    const cartCountElement = document.querySelector('.cart-count');
    if (cartCountElement) {
        cartCountElement.textContent = count;
    }
}

// Add to Cart Functionality
function handleAddToCart(productId, quantity = 1) {
    fetch('/add_to_cart', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            product_id: productId,
            quantity: quantity
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateCartCount(data.cart_count);
            showNotification('Product added to cart successfully!');
        } else {
            showNotification(data.message || 'Failed to add product to cart', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('An error occurred while adding to cart', 'error');
    });
}

// Cart Management
function updateQuantity(productId, newQuantity) {
    if (newQuantity < 1) {
        removeItem(productId);
        return;
    }
    
    fetch('/update_cart_quantity', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            product_id: productId,
            quantity: newQuantity
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        }
    });
}

function removeItem(productId) {
    fetch('/remove_from_cart', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            product_id: productId
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        }
    });
}

// Product Filtering
function filterProducts() {
    const willowFilter = document.getElementById('willow-filter');
    const priceFilter = document.getElementById('price-filter');
    const weightFilter = document.getElementById('weight-filter');
    
    if (!willowFilter || !priceFilter || !weightFilter) return;
    
    const willowValue = willowFilter.value;
    const priceValue = priceFilter.value;
    const weightValue = weightFilter.value;
    
    const productCards = document.querySelectorAll('.product-card');
    
    productCards.forEach(card => {
        let show = true;
        
        if (willowValue && card.dataset.willow !== willowValue) {
            show = false;
        }
        
        if (priceValue) {
            const price = parseInt(card.dataset.price);
            const [min, max] = priceValue.split('-').map(v => parseInt(v) || Infinity);
            if (price < min || (max !== Infinity && price > max)) {
                show = false;
            }
        }
        
        if (weightValue && card.dataset.weight !== weightValue) {
            show = false;
        }
        
        card.style.display = show ? 'block' : 'none';
    });
}

// Tab Switching
function switchTab(tabName) {
    document.querySelectorAll('.tab-btn, .tab-button').forEach(btn => {
        btn.classList.remove('active');
    });
    document.querySelectorAll('.tab-pane, .tab-panel').forEach(panel => {
        panel.classList.remove('active');
    });
    
    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    document.getElementById(tabName).classList.add('active');
}

// Quantity Controls
function setupQuantityControls() {
    const quantityInput = document.getElementById('quantity');
    const minusBtn = document.querySelector('.qty-btn.minus');
    const plusBtn = document.querySelector('.qty-btn.plus');
    
    if (minusBtn && quantityInput) {
        minusBtn.addEventListener('click', () => {
            const current = parseInt(quantityInput.value);
            if (current > 1) {
                quantityInput.value = current - 1;
            }
        });
    }
    
    if (plusBtn && quantityInput) {
        plusBtn.addEventListener('click', () => {
            const current = parseInt(quantityInput.value);
            if (current < 5) {
                quantityInput.value = current + 1;
            }
        });
    }
}

// Thumbnail Gallery
function setupThumbnailGallery() {
    const thumbnails = document.querySelectorAll('.thumbnail');
    thumbnails.forEach(thumb => {
        thumb.addEventListener('click', () => {
            thumbnails.forEach(t => t.classList.remove('active'));
            thumb.classList.add('active');
        });
    });
}

// Quiz Functionality for Homepage
function initializeHomepageQuiz() {
    const quizCard = document.getElementById('quiz-card');
    if (!quizCard) return;
    
    const simpleQuizData = [
        {
            question: "What's your playing style?",
            options: [
                { value: "aggressive", label: "Aggressive Batsman", desc: "Power hitting, boundaries, big shots" },
                { value: "technical", label: "Technical Player", desc: "Precise shots, timing, placement" },
                { value: "allround", label: "All-Rounder", desc: "Balanced approach, versatile" },
                { value: "defensive", label: "Defensive Player", desc: "Patient batting, long innings" }
            ]
        },
        {
            question: "What's your experience level?",
            options: [
                { value: "beginner", label: "Beginner", desc: "Just starting out" },
                { value: "club", label: "Club Level", desc: "Regular local matches" },
                { value: "state", label: "State Level", desc: "Competitive tournaments" },
                { value: "professional", label: "Professional", desc: "High-level cricket" }
            ]
        },
        {
            question: "What's your preferred bat weight?",
            options: [
                { value: "light", label: "Light (2.6-2.8 lbs)", desc: "Quick swing, good control" },
                { value: "medium", label: "Medium (2.8-3.0 lbs)", desc: "Balanced feel" },
                { value: "heavy", label: "Heavy (3.0+ lbs)", desc: "More power, momentum" }
            ]
        },
        {
            question: "What's your budget range?",
            options: [
                { value: "budget", label: "Under ₹10,000", desc: "Great value options" },
                { value: "mid", label: "₹10,000 - ₹20,000", desc: "Premium quality" },
                { value: "premium", label: "Above ₹20,000", desc: "Professional grade" }
            ]
        }
    ];
    
    let currentQuestion = 0;
    let answers = {};
    
    function showQuestion(index) {
        const question = simpleQuizData[index];
        document.getElementById('question-text').textContent = question.question;
        document.getElementById('current-question').textContent = index + 1;
        document.getElementById('total-questions').textContent = simpleQuizData.length;
        
        const optionsContainer = document.getElementById('quiz-options');
        optionsContainer.innerHTML = '';
        
        question.options.forEach(option => {
            const optionElement = document.createElement('div');
            optionElement.className = 'quiz-option';
            optionElement.dataset.value = option.value;
            optionElement.innerHTML = `
                <h4>${option.label}</h4>
                <p>${option.desc}</p>
            `;
            optionElement.onclick = () => selectOption(option.value);
            
            if (answers[index] === option.value) {
                optionElement.classList.add('selected');
            }
            
            optionsContainer.appendChild(optionElement);
        });
        
        document.getElementById('prev-btn').disabled = index === 0;
    }
    
    function selectOption(value) {
        answers[currentQuestion] = value;
        document.querySelectorAll('.quiz-option').forEach(opt => opt.classList.remove('selected'));
        document.querySelector(`[data-value="${value}"]`).classList.add('selected');
    }
    
    window.nextQuestion = function() {
        if (currentQuestion < simpleQuizData.length - 1) {
            currentQuestion++;
            showQuestion(currentQuestion);
        } else {
            showResults();
        }
    };
    
    window.previousQuestion = function() {
        if (currentQuestion > 0) {
            currentQuestion--;
            showQuestion(currentQuestion);
        }
    };
    
    function showResults() {
        const products = [
            { id: 1, name: 'Cricket Secret Pro Elite', price: 7890 },
            { id: 2, name: 'Cricket Secret Classic Master', price: 10999 },
            { id: 3, name: 'Cricket Secret Premium Legend', price: 15678 },
            { id: 4, name: 'Cricket Secret Ultimate Champion', price: 23456 }
        ];
        
        const userAnswers = Object.values(answers);
        const recommendations = products.slice(0, 3);
        
        quizCard.innerHTML = `
            <div class="quiz-results-header">
                <h2>Your Perfect Cricket Bat Recommendations</h2>
                <p>Based on your answers, here are the best matches for you:</p>
            </div>
            <div class="recommended-bats">
                ${recommendations.map((product, index) => `
                    <div class="recommendation-card ${index === 0 ? 'top-pick' : ''}">
                        ${index === 0 ? '<div class="top-pick-badge">TOP PICK</div>' : ''}
                        <div class="rec-bat-visual">
                            <div class="rec-bat-logo">
                                <img src="/static/images/logo.png" alt="Cricket Secret" style="width: 30px; height: 30px;">
                            </div>
                        </div>
                        <h3>${product.name}</h3>
                        <p class="rec-price">₹${product.price.toLocaleString()}</p>
                        <p class="match-score">${Math.round(((4 - index) / 4) * 100)}% Match</p>
                        <a href="/product/${product.id}" class="rec-btn">View Details</a>
                    </div>
                `).join('')}
            </div>
            <div class="quiz-actions">
                <button class="quiz-btn" onclick="restartQuiz()">Retake Quiz</button>
                <a href="/products" class="quiz-btn secondary">View All Products</a>
            </div>
        `;
    }
    
    window.restartQuiz = function() {
        currentQuestion = 0;
        answers = {};
        quizCard.innerHTML = `
            <div class="quiz-question">
                <h3 id="question-text">What's your playing style?</h3>
            </div>
            <div class="quiz-options" id="quiz-options">
                <!-- Options populated by JavaScript -->
            </div>
            <div class="quiz-nav">
                <button class="quiz-btn" id="prev-btn" onclick="previousQuestion()" disabled>Previous</button>
                <div class="quiz-progress">
                    <span id="current-question">1</span> / <span id="total-questions">4</span>
                </div>
                <button class="quiz-btn" id="next-btn" onclick="nextQuestion()">Next</button>
            </div>
        `;
        showQuestion(0);
    };
    
    // Initialize quiz
    showQuestion(0);
}

// Payment handling
function handlePayment() {
    const paymentMethod = document.querySelector('input[name="payment_method"]:checked');
    if (!paymentMethod) {
        showNotification('Please select a payment method', 'error');
        return;
    }
    
    if (paymentMethod.value === 'cod') {
        // Handle Cash on Delivery
        window.location.href = '/order-success?method=cod';
        return;
    }
    
    // Handle Razorpay payment
    fetch('/create_order', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const options = {
                key: document.getElementById('razorpay-key').value,
                amount: data.amount,
                currency: data.currency,
                order_id: data.order_id,
                name: 'Cricket Secret',
                description: 'Premium Cricket Bats',
                image: '/static/images/logo.png',
                handler: function(response) {
                    verifyPayment(response);
                },
                prefill: {
                    name: document.getElementById('full-name').value,
                    email: document.getElementById('email').value,
                    contact: document.getElementById('phone').value
                },
                theme: {
                    color: '#2c5aa0'
                }
            };
            
            const rzp = new Razorpay(options);
            rzp.open();
        } else {
            showNotification(data.message || 'Failed to create order', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('An error occurred while processing payment', 'error');
    });
}

function verifyPayment(response) {
    fetch('/verify_payment', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(response)
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            window.location.href = `/order-success?order_id=${data.order_id}&method=online`;
        } else {
            showNotification('Payment verification failed', 'error');
        }
    });
}

// Mobile menu toggle
function toggleMobileMenu() {
    const navMenu = document.querySelector('.nav-menu');
    const hamburger = document.querySelector('.hamburger');

    if (navMenu) navMenu.classList.toggle('active');
    if (hamburger) hamburger.classList.toggle('active');
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize cart count
    updateCartCount(0);
    
    // Initialize homepage quiz if present
    initializeHomepageQuiz();
    
    // Setup quantity controls
    setupQuantityControls();
    
    // Setup thumbnail gallery
    setupThumbnailGallery();
    
    // Add to cart buttons
    document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = parseInt(this.dataset.productId);
            const quantitySelector = document.getElementById('quantity');
            const quantity = quantitySelector ? parseInt(quantitySelector.value) : 1;
            handleAddToCart(productId, quantity);
        });
    });

    // Filter dropdowns
    ['willow-filter', 'price-filter', 'weight-filter'].forEach(filterId => {
        const filter = document.getElementById(filterId);
        if (filter) {
            filter.addEventListener('change', filterProducts);
        }
    });

    // Tab buttons
    document.querySelectorAll('.tab-btn, .tab-button').forEach(btn => {
        btn.addEventListener('click', function() {
            switchTab(this.dataset.tab);
        });
    });

    // Mobile menu
    const hamburger = document.querySelector('.hamburger');
    if (hamburger) {
        hamburger.addEventListener('click', toggleMobileMenu);
    }

    // Payment button
    const paymentBtn = document.getElementById('payment-btn');
    if (paymentBtn) {
        paymentBtn.addEventListener('click', handlePayment);
    }
});

// Global functions for window access
window.cricketSecret = {
    updateQuantity,
    removeItem,
    showNotification,
    handleAddToCart,
    filterProducts,
    switchTab,
    nextQuestion,
    previousQuestion,
    handlePayment
};
