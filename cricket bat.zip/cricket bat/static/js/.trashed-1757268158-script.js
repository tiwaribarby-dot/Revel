// Utility functions
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// Show notification
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas ${type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}"></i>
        ${message}
    `;

    document.body.appendChild(notification);

    setTimeout(() => {
        notification.classList.add('show');
    }, 100);

    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Add to cart functionality
function handleAddToCart(productId, quantity = 1) {
    fetch('/add_to_cart', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            product_id: productId,
            quantity: quantity
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateCartCount(data.cart_count);
            showNotification('Product added to cart!', 'success');
        } else {
            showNotification('Failed to add product to cart', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('An error occurred', 'error');
    });
}

// Dynamic Cricket Bat Image Generation
function createBatImage(productName, price) {
    const canvas = document.createElement('canvas');
    canvas.width = 400;
    canvas.height = 280;
    const ctx = canvas.getContext('2d');

    // Create gradient background
    const gradient = ctx.createLinearGradient(0, 0, 400, 280);
    gradient.addColorStop(0, '#8B4513');
    gradient.addColorStop(0.3, '#D2691E');
    gradient.addColorStop(0.6, '#F4A460');
    gradient.addColorStop(1, '#D2691E');

    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 400, 280);

    // Draw bat shape
    ctx.fillStyle = '#654321';
    ctx.beginPath();
    ctx.roundRect(150, 40, 100, 200, 10);
    ctx.fill();

    // Add logo area
    ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.fillRect(160, 60, 80, 30);

    // Add product name
    ctx.fillStyle = 'white';
    ctx.font = 'bold 14px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Cricket Secret', 200, 80);

    // Add price
    ctx.fillStyle = '#FFD700';
    ctx.font = 'bold 16px Arial';
    ctx.fillText(`₹${price}`, 200, 220);

    return canvas.toDataURL();
}

// Replace missing bat images with generated ones
function replaceMissingImages() {
    document.querySelectorAll('img').forEach(img => {
        if (img.src.includes('bat') && img.naturalWidth === 0) {
            img.onerror = null;
            const productCard = img.closest('.product-card');
            if (productCard) {
                const productName = productCard.querySelector('h3')?.textContent || 'Cricket Bat';
                const priceText = productCard.querySelector('.price')?.textContent || '0';
                const price = priceText.replace(/[^\d]/g, '');

                // Create styled div instead of canvas for better control
                const batContainer = document.createElement('div');
                batContainer.className = 'bat-image-container';
                batContainer.style.cssText = `
                    width: 100%;
                    height: 280px;
                    background: linear-gradient(45deg, #8B4513 0%, #D2691E 30%, #F4A460 60%, #D2691E 100%);
                    position: relative;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    overflow: hidden;
                `;

                // Add bat shape
                const batShape = document.createElement('div');
                batShape.style.cssText = `
                    width: 80px;
                    height: 200px;
                    background: linear-gradient(to bottom, #654321, #4a2c17);
                    border-radius: 40px 40px 10px 10px;
                    position: relative;
                    box-shadow: inset 0 0 20px rgba(0,0,0,0.3);
                `;

                // Add logo area
                const logoArea = document.createElement('div');
                logoArea.style.cssText = `
                    position: absolute;
                    top: 20px;
                    left: 50%;
                    transform: translateX(-50%);
                    width: 60px;
                    height: 20px;
                    background: rgba(255,255,255,0.9);
                    border-radius: 5px;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 8px;
                    font-weight: bold;
                    color: #333;
                `;
                logoArea.textContent = 'CS';

                // Add brand text
                const brandText = document.createElement('div');
                brandText.style.cssText = `
                    position: absolute;
                    bottom: 20px;
                    left: 50%;
                    transform: translateX(-50%);
                    color: white;
                    font-weight: bold;
                    font-size: 12px;
                    text-shadow: 2px 2px 4px rgba(0,0,0,0.8);
                    letter-spacing: 1px;
                `;
                brandText.textContent = 'CRICKET SECRET';

                batShape.appendChild(logoArea);
                batContainer.appendChild(batShape);
                batContainer.appendChild(brandText);

                img.style.display = 'none';
                img.parentNode.insertBefore(batContainer, img);
            }
        }
    });
}

// Update cart quantity
async function updateQuantity(productId, change) {
    const quantityElement = document.querySelector(`[data-product-id="${productId}"] .quantity`);
    let currentQuantity = parseInt(quantityElement.textContent);
    let newQuantity = currentQuantity + change;

    if (newQuantity < 0) newQuantity = 0;

    try {
        const response = await fetch('/update_cart_quantity', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                product_id: productId,
                quantity: newQuantity
            })
        });

        const result = await response.json();

        if (result.success) {
            if (newQuantity === 0) {
                location.reload(); // Refresh page to remove item
            } else {
                quantityElement.textContent = newQuantity;
                updateCartTotals();
            }
        }
    } catch (error) {
        console.error('Update quantity error:', error);
        showNotification('Failed to update quantity', 'error');
    }
}

// Remove item from cart
async function removeItem(productId) {
    try {
        const response = await fetch('/remove_from_cart', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                product_id: productId
            })
        });

        const result = await response.json();

        if (result.success) {
            location.reload(); // Refresh page to remove item
        }
    } catch (error) {
        console.error('Remove item error:', error);
        showNotification('Failed to remove item', 'error');
    }
}

// Update cart count in header
function updateCartCount(count) {
    const cartCountElement = document.querySelector('.cart-count');
    if (cartCountElement) {
        cartCountElement.textContent = count;
    }
}

// Update cart totals on cart page
function updateCartTotals() {
    let subtotal = 0;
    document.querySelectorAll('.cart-item').forEach(item => {
        const price = parseFloat(item.querySelector('.price').textContent.replace('₹', ''));
        const quantity = parseInt(item.querySelector('.quantity').textContent);
        subtotal += price * quantity;
    });

    const shipping = subtotal > 5000 ? 0 : 100;
    const tax = subtotal * 0.18;
    const total = subtotal + shipping + tax;

    // Update summary if it exists
    const summaryElement = document.querySelector('.cart-summary');
    if (summaryElement) {
        summaryElement.querySelector('.subtotal').textContent = `₹${subtotal.toFixed(2)}`;
        summaryElement.querySelector('.shipping').textContent = shipping === 0 ? 'Free' : `₹${shipping}`;
        summaryElement.querySelector('.tax').textContent = `₹${tax.toFixed(2)}`;
        summaryElement.querySelector('.total').textContent = `₹${total.toFixed(2)}`;
    }
}

// Buy now functionality
function handleBuyNow(productId) {
    handleAddToCart(productId, 1).then(() => {
        setTimeout(() => {
            window.location.href = '/checkout';
        }, 1000);
    });
}

// Filter products on products page
function filterProducts() {
    const willowFilter = document.getElementById('willow-filter')?.value || '';
    const priceFilter = document.getElementById('price-filter')?.value || '';
    const weightFilter = document.getElementById('weight-filter')?.value || '';

    document.querySelectorAll('.product-card').forEach(card => {
        let show = true;

        if (willowFilter && !card.dataset.willow.includes(willowFilter)) {
            show = false;
        }

        if (priceFilter) {
            const price = parseInt(card.dataset.price);
            const [min, max] = priceFilter.split('-').map(p => parseInt(p) || Infinity);
            if (price < min || (max !== Infinity && price > max)) {
                show = false;
            }
        }

        if (weightFilter && card.dataset.weight !== weightFilter) {
            show = false;
        }

        card.style.display = show ? 'block' : 'none';
    });
}

// Product detail tabs
function switchTab(tabName) {
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-pane').forEach(pane => pane.classList.remove('active'));

    document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');
    document.getElementById(tabName).classList.add('active');
}

// Mobile menu toggle
function toggleMobileMenu() {
    const navMenu = document.querySelector('.nav-menu');
    const hamburger = document.querySelector('.hamburger');

    navMenu.classList.toggle('active');
    hamburger.classList.toggle('active');
}

// Initialize event listeners when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Add to cart buttons
    document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = parseInt(this.dataset.productId);
            const quantitySelector = document.getElementById('quantity');
            const quantity = quantitySelector ? parseInt(quantitySelector.value) : 1;
            handleAddToCart(productId, quantity);
        });
    });

    // Buy now buttons
    document.querySelectorAll('.buy-now-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = parseInt(this.closest('.product-actions, .purchase-section').querySelector('.add-to-cart-btn').dataset.productId);
            handleBuyNow(productId);
        });
    });

    // Filter dropdowns
    ['willow-filter', 'price-filter', 'weight-filter'].forEach(filterId => {
        const filter = document.getElementById(filterId);
        if (filter) {
            filter.addEventListener('change', filterProducts);
        }
    });

    // Tab buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            switchTab(this.dataset.tab);
        });
    });

    // Mobile menu
    const hamburger = document.querySelector('.hamburger');
    if (hamburger) {
        hamburger.addEventListener('click', toggleMobileMenu);
    }

    // Star rating input
    document.querySelectorAll('.stars-input i').forEach(star => {
        star.addEventListener('click', function() {
            const rating = this.dataset.rating;
            document.querySelectorAll('.stars-input i').forEach((s, index) => {
                if (index < rating) {
                    s.className = 'fas fa-star';
                } else {
                    s.className = 'far fa-star';
                }
            });
        });
    });

    // Call function to replace missing images
    replaceMissingImages();
});

// Performance optimization: Preload critical images
function preloadCriticalImages() {
    const criticalImages = [
        '/static/images/hero-bat.jpg',
        '/static/images/bat1.jpg',
        '/static/images/bat2.jpg',
        '/static/images/logo.png'
    ];

    criticalImages.forEach(src => {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.as = 'image';
        link.href = src;
        document.head.appendChild(link);
    });
}

// Call preload function
preloadCriticalImages();

// Add to window for global access
window.cricketSecret = {
    updateQuantity,
    removeItem,
    showNotification,
    handleAddToCart,
    handleBuyNow,
    filterProducts,
    switchTab
};