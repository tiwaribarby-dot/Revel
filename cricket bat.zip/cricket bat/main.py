from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, FloatField, IntegerField, SelectField, SubmitField, RadioField
from wtforms.validators import DataRequired, Email, NumberRange
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os
import json
import razorpay

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///cricket_store.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Razorpay configuration
RAZORPAY_KEY_ID = 'rzp_test_hkQ8kyfqkMQNiq'
RAZORPAY_KEY_SECRET = 'K6gCxmb2MlS3GjNvksZl94K4'
razorpay_client = razorpay.Client(auth=(RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET))

db = SQLAlchemy(app)

# Database Models
class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Float, nullable=False)
    image_url = db.Column(db.String(200), nullable=False)
    category = db.Column(db.String(50), nullable=False)
    weight = db.Column(db.String(20))
    grade = db.Column(db.String(20))
    willow_type = db.Column(db.String(50))
    in_stock = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Customer(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))
    phone = db.Column(db.String(20))
    address = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    total_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='pending')
    payment_method = db.Column(db.String(50))
    payment_id = db.Column(db.String(100))
    razorpay_order_id = db.Column(db.String(100))
    shipping_address = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    items = db.relationship('OrderItem', backref='order', lazy=True)

class OrderItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('order.id'), nullable=False)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    price = db.Column(db.Float, nullable=False)
    customization = db.Column(db.Text)  # JSON string for customization options

class Review(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    product_id = db.Column(db.Integer, db.ForeignKey('product.id'), nullable=False)
    customer_name = db.Column(db.String(100), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    comment = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# Forms
class ReviewForm(FlaskForm):
    customer_name = StringField('Name', validators=[DataRequired()])
    rating = SelectField('Rating', choices=[(5, '5 Stars'), (4, '4 Stars'), (3, '3 Stars'), (2, '2 Stars'), (1, '1 Star')], coerce=int, validators=[DataRequired()])
    comment = TextAreaField('Review')
    submit = SubmitField('Submit Review')

class ProductCustomizationForm(FlaskForm):
    willow_type = RadioField('Willow Type', choices=[
        ('english_willow', 'English Willow - ₹7,890'),
        ('duo_core_willow', 'Duo Core Willow - ₹10,999'),
        ('premium_english_willow', 'Premium English Willow - ₹15,678'),
        ('practice_willow', 'Practice Willow - ₹2,345')
    ], validators=[DataRequired()])

    practice_type = RadioField('Practice Type', choices=[
        ('hitter', 'Hitter'),
        ('classic', 'Classic'),
        ('pro_training', 'Pro Training')
    ], validators=[DataRequired()])

    handle_length = RadioField('Handle', choices=[
        ('short', 'Short'),
        ('long', 'Long')
    ], validators=[DataRequired()])

    toe_type = RadioField('Toe Type', choices=[
        ('semi_round', 'Semi Round'),
        ('round', 'Round'),
        ('flat', 'Flat')
    ], validators=[DataRequired()])

    handle_type = RadioField('Handle Type', choices=[
        ('round', 'Round Handle'),
        ('semi_oval', 'Semi Oval Handle'),
        ('fully_oval', 'Fully Oval Handle')
    ], validators=[DataRequired()])

    weight_preference = RadioField('Weight', choices=[
        ('light', 'Light'),
        ('well_balanced', 'Well Balanced'),
        ('heavy', 'Heavy')
    ], validators=[DataRequired()])

    pressing = RadioField('Pressing', choices=[
        ('balanced_press', 'Balanced Press'),
        ('heavy_press', 'Heavy Press'),
        ('fully_pressed', 'Fully Pressed'),
        ('normal_pressed', 'Normal Pressed')
    ], validators=[DataRequired()])

class CheckoutForm(FlaskForm):
    name = StringField('Full Name', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    phone = StringField('Phone', validators=[DataRequired()])
    address = TextAreaField('Shipping Address', validators=[DataRequired()])
    submit = SubmitField('Proceed to Payment')

# Routes
@app.route('/')
def index():
    featured_products = Product.query.limit(4).all()
    return render_template('index.html', products=featured_products)

@app.route('/products')
def products():
    category = request.args.get('category', 'all')
    if category == 'all':
        products = Product.query.filter_by(in_stock=True).all()
    else:
        products = Product.query.filter_by(category=category, in_stock=True).all()

    categories = ['all', 'professional', 'premium', 'training', 'practice']
    return render_template('products.html', products=products, categories=categories, current_category=category)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    product = Product.query.get_or_404(product_id)
    reviews = Review.query.filter_by(product_id=product_id).order_by(Review.created_at.desc()).all()
    form = ReviewForm()
    customization_form = ProductCustomizationForm()

    # Calculate average rating
    avg_rating = 0
    if reviews:
        avg_rating = sum(review.rating for review in reviews) / len(reviews)

    return render_template('product_detail.html', product=product, reviews=reviews, 
                         form=form, customization_form=customization_form, avg_rating=avg_rating)

@app.route('/customize_product/<int:product_id>', methods=['POST'])
def customize_product(product_id):
    form = ProductCustomizationForm()
    if form.validate_on_submit():
        customization = {
            'willow_type': form.willow_type.data,
            'practice_type': form.practice_type.data,
            'handle_length': form.handle_length.data,
            'toe_type': form.toe_type.data,
            'handle_type': form.handle_type.data,
            'weight_preference': form.weight_preference.data,
            'pressing': form.pressing.data
        }

        # Calculate price based on willow type
        willow_prices = {
            'english_willow': 7890,
            'duo_core_willow': 10999,
            'premium_english_willow': 15678,
            'practice_willow': 2345
        }

        base_price = willow_prices.get(form.willow_type.data, 7890)

        # Store customization in session
        session['customization'] = customization
        session['custom_price'] = base_price
        session.permanent = True

        flash('Product customized successfully! Add to cart to proceed.', 'success')
        return redirect(url_for('product_detail', product_id=product_id))

    flash('Please complete all customization options.', 'error')
    return redirect(url_for('product_detail', product_id=product_id))

@app.route('/add_review/<int:product_id>', methods=['POST'])
def add_review(product_id):
    form = ReviewForm()
    if form.validate_on_submit():
        review = Review(
            product_id=product_id,
            customer_name=form.customer_name.data,
            rating=form.rating.data,
            comment=form.comment.data
        )
        db.session.add(review)
        db.session.commit()
        flash('Thank you for your review!', 'success')
    return redirect(url_for('product_detail', product_id=product_id))

@app.route('/add_to_cart/<int:product_id>')
def add_to_cart(product_id):
    product = Product.query.get_or_404(product_id)

    if 'cart' not in session:
        session['cart'] = []

    # Get customization and price from session
    customization = session.get('customization', {})
    custom_price = session.get('custom_price', product.price)

    # Check if product already in cart
    for item in session['cart']:
        if item['id'] == product_id:
            item['quantity'] += 1
            break
    else:
        session['cart'].append({
            'id': product_id,
            'name': product.name,
            'price': custom_price,
            'image_url': product.image_url,
            'quantity': 1,
            'customization': customization
        })

    # Clear customization from session
    session.pop('customization', None)
    session.pop('custom_price', None)
    session.permanent = True

    flash(f'{product.name} added to cart!', 'success')
    return redirect(url_for('products'))

@app.route('/cart')
def cart():
    cart_items = session.get('cart', [])
    total = sum(item['price'] * item['quantity'] for item in cart_items)
    return render_template('cart.html', cart_items=cart_items, total=total)

@app.route('/remove_from_cart/<int:product_id>')
def remove_from_cart(product_id):
    if 'cart' in session:
        session['cart'] = [item for item in session['cart'] if item['id'] != product_id]
        session.permanent = True
    return redirect(url_for('cart'))

@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    cart_items = session.get('cart', [])
    if not cart_items:
        flash('Your cart is empty!', 'warning')
        return redirect(url_for('products'))

    form = CheckoutForm()
    total = sum(item['price'] * item['quantity'] for item in cart_items)

    if form.validate_on_submit():
        # Create Razorpay order
        razorpay_order = razorpay_client.order.create({
            'amount': int(total * 100),  # Amount in paise
            'currency': 'INR',
            'payment_capture': 1
        })

        # Store order details in session
        session['checkout_form'] = {
            'name': form.name.data,
            'email': form.email.data,
            'phone': form.phone.data,
            'address': form.address.data
        }
        session['razorpay_order_id'] = razorpay_order['id']
        session.permanent = True

        return render_template('payment.html', 
                             order=razorpay_order, 
                             total=total, 
                             key_id=RAZORPAY_KEY_ID,
                             customer=form)

    return render_template('checkout.html', form=form, cart_items=cart_items, total=total)

@app.route('/payment_success', methods=['POST'])
def payment_success():
    payment_id = request.form.get('razorpay_payment_id')
    order_id = request.form.get('razorpay_order_id')
    signature = request.form.get('razorpay_signature')

    # Verify payment signature
    try:
        razorpay_client.utility.verify_payment_signature({
            'razorpay_order_id': order_id,
            'razorpay_payment_id': payment_id,
            'razorpay_signature': signature
        })

        # Create order in database
        cart_items = session.get('cart', [])
        checkout_form = session.get('checkout_form', {})
        total = sum(item['price'] * item['quantity'] for item in cart_items)

        order = Order(
            customer_id=1,  # For demo purposes
            total_amount=total,
            payment_method='razorpay',
            payment_id=payment_id,
            razorpay_order_id=order_id,
            status='completed',
            shipping_address=checkout_form.get('address', '')
        )
        db.session.add(order)
        db.session.commit()

        # Add order items
        for item in cart_items:
            order_item = OrderItem(
                order_id=order.id,
                product_id=item['id'],
                quantity=item['quantity'],
                price=item['price'],
                customization=json.dumps(item.get('customization', {}))
            )
            db.session.add(order_item)

        db.session.commit()

        # Clear cart and session data
        session.pop('cart', None)
        session.pop('checkout_form', None)
        session.pop('razorpay_order_id', None)

        flash('Payment successful! Your order has been confirmed.', 'success')
        return redirect(url_for('order_confirmation', order_id=order.id))

    except Exception as e:
        flash('Payment verification failed. Please try again.', 'error')
        return redirect(url_for('checkout'))

@app.route('/order_confirmation/<int:order_id>')
def order_confirmation(order_id):
    order = Order.query.get_or_404(order_id)
    return render_template('order_confirmation.html', order=order)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

# Initialize database and sample data
def init_db():
    with app.app_context():
        db.create_all()

        # Add sample products
        sample_products = [
            Product(
                name="Cricket Secret Professional Elite",
                description="Premium cricket bat crafted from Grade A+ English willow with professional customization options. Perfect balance and power for elite players.",
                price=7890.00,
                image_url="/static/images/bat1.jpg",
                category="professional",
                weight="1.2kg - 1.3kg",
                grade="Grade A+",
                willow_type="English Willow"
            ),
            Product(
                name="Cricket Secret Duo Core Master",
                description="High-performance cricket bat with Duo Core willow technology. Exceptional power and durability for serious cricketers.",
                price=10999.00,
                image_url="/static/images/bat2.jpg",
                category="professional",
                weight="1.1kg - 1.2kg",
                grade="Grade A+",
                willow_type="Duo Core Willow"
            ),
            Product(
                name="Cricket Secret Premium Classic",
                description="Premium English willow bat with traditional craftsmanship and modern performance. The ultimate choice for champions.",
                price=15678.00,
                image_url="/static/images/bat3.jpg",
                category="premium",
                weight="1.2kg - 1.3kg",
                grade="Grade A++",
                willow_type="Premium English Willow"
            ),
            Product(
                name="Cricket Secret Practice Pro",
                description="Durable practice cricket bat perfect for training sessions. Built to withstand intensive practice while maintaining performance.",
                price=2345.00,
                image_url="/static/images/bat4.jpg",
                category="practice",
                weight="1.0kg - 1.1kg",
                grade="Grade B+",
                willow_type="Practice Willow"
            )
        ]

        for product in sample_products:
            db.session.add(product)

        db.session.commit()

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000, debug=True)