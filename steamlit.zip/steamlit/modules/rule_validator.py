import re
from typing import Dict, Any, List

class RuleValidator:
    """Validator for French news transition rules"""
    
    def __init__(self):
        self.max_word_count = 5
        self.concluding_indicators = [
            'pour finir', 'enfin', 'finalement', 'en conclusion', 
            'pour conclure', 'en dernier lieu', 'pour terminer',
            'dernièrement', 'en définitive', 'au final'
        ]
    
    def validate_transition(self, transition: Dict[str, Any]) -> Dict[str, bool]:
        """
        Validate a single transition against all rules
        
        Args:
            transition: Transition dictionary from parser
            
        Returns:
            Dictionary of rule validation results
        """
        results = {}
        
        # Rule 1: Word count limit (≤5 words)
        results['word_limit'] = self._check_word_limit(transition)
        
        # Rule 2: Concluding placement (concluding transitions only at the end)
        results['concluding_placement'] = self._check_concluding_placement(transition)
        
        return results
    
    def _check_word_limit(self, transition: Dict[str, Any]) -> bool:
        """
        Check if transition respects the 5-word limit
        
        Args:
            transition: Transition dictionary
            
        Returns:
            True if word count is ≤5, False otherwise
        """
        text = transition.get('clean_text', transition.get('text', ''))
        word_count = len(text.split())
        return word_count <= self.max_word_count
    
    def _check_concluding_placement(self, transition: Dict[str, Any]) -> bool:
        """
        Check if concluding transitions are properly placed
        
        Args:
            transition: Transition dictionary
            
        Returns:
            True if placement is correct, False otherwise
        """
        text = transition.get('text', '').lower()
        is_concluding_transition = any(indicator in text for indicator in self.concluding_indicators)
        is_in_final_position = transition.get('is_concluding', False)
        
        # If it's a concluding transition, it should be in the final position
        # If it's not a concluding transition, it should not be in the final position (relaxed for now)
        if is_concluding_transition and not is_in_final_position:
            return False
        
        return True
    
    def _is_concluding_transition(self, text: str) -> bool:
        """
        Determine if a transition is a concluding type
        
        Args:
            text: Transition text
            
        Returns:
            True if it's a concluding transition
        """
        text_lower = text.lower()
        return any(indicator in text_lower for indicator in self.concluding_indicators)
    
    def get_rule_explanations(self) -> Dict[str, str]:
        """
        Get explanations for each rule
        
        Returns:
            Dictionary mapping rule names to explanations
        """
        return {
            'word_limit': f"Transitions must not exceed {self.max_word_count} words",
            'concluding_placement': "Concluding transitions should only appear in the final position"
        }
    
    def validate_all_transitions(self, transitions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Validate all transitions in an article
        
        Args:
            transitions: List of transition dictionaries
            
        Returns:
            List of transitions with validation results added
        """
        validated_transitions = []
        
        for transition in transitions:
            validation_results = self.validate_transition(transition)
            
            # Add validation results to transition
            enhanced_transition = transition.copy()
            enhanced_transition['rule_validation'] = validation_results
            enhanced_transition['passes_all_rules'] = all(validation_results.values())
            
            # Add specific failure information
            failed_rules = [rule for rule, passed in validation_results.items() if not passed]
            enhanced_transition['failed_rules'] = failed_rules
            
            validated_transitions.append(enhanced_transition)
        
        return validated_transitions
    
    def get_validation_summary(self, transitions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Get a summary of validation results for all transitions
        
        Args:
            transitions: List of validated transition dictionaries
            
        Returns:
            Summary statistics
        """
        total_transitions = len(transitions)
        passing_transitions = sum(1 for t in transitions if t.get('passes_all_rules', False))
        
        rule_failures = {}
        for transition in transitions:
            for failed_rule in transition.get('failed_rules', []):
                rule_failures[failed_rule] = rule_failures.get(failed_rule, 0) + 1
        
        return {
            'total_transitions': total_transitions,
            'passing_transitions': passing_transitions,
            'failing_transitions': total_transitions - passing_transitions,
            'pass_rate': (passing_transitions / total_transitions * 100) if total_transitions > 0 else 0,
            'rule_failures': rule_failures
        }
    
    def check_custom_rules(self, transition: Dict[str, Any], custom_rules: Dict[str, Any]) -> Dict[str, bool]:
        """
        Apply custom validation rules
        
        Args:
            transition: Transition dictionary
            custom_rules: Dictionary of custom rules and their parameters
            
        Returns:
            Dictionary of custom rule validation results
        """
        results = {}
        
        # Custom word limit
        if 'max_words' in custom_rules:
            text = transition.get('clean_text', transition.get('text', ''))
            word_count = len(text.split())
            results['custom_word_limit'] = word_count <= custom_rules['max_words']
        
        # Custom forbidden phrases
        if 'forbidden_phrases' in custom_rules:
            text = transition.get('text', '').lower()
            has_forbidden = any(phrase.lower() in text for phrase in custom_rules['forbidden_phrases'])
            results['no_forbidden_phrases'] = not has_forbidden
        
        # Custom required elements
        if 'required_elements' in custom_rules:
            text = transition.get('text', '').lower()
            has_required = any(element.lower() in text for element in custom_rules['required_elements'])
            results['has_required_elements'] = has_required
        
        return results
