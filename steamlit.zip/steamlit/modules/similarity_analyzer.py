try:
    from sentence_transformers import SentenceTransformer
    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False
    SentenceTransformer = None

import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
from typing import Dict, Any, List, Optional
import logging

class SimilarityAnalyzer:
    """Semantic similarity analyzer for transitions"""
    
    def __init__(self, model_name: str = "paraphrase-multilingual-MiniLM-L12-v2"):
        self.logger = logging.getLogger(__name__)
        self.model_name = model_name
        self.model = self._load_model()
        self.use_tfidf_fallback = not SENTENCE_TRANSFORMERS_AVAILABLE or self.model is None
        
        if self.use_tfidf_fallback:
            self.logger.info("Using TF-IDF fallback for similarity analysis")
            self.tfidf_vectorizer = TfidfVectorizer(
                max_features=1000,
                stop_words=None,  # Keep French stopwords
                ngram_range=(1, 2),
                lowercase=True
            )
    
    def _load_model(self) -> Optional[SentenceTransformer]:
        """Load the sentence transformer model"""
        if not SENTENCE_TRANSFORMERS_AVAILABLE:
            self.logger.warning("sentence-transformers not available, will use TF-IDF fallback")
            return None
            
        try:
            model = SentenceTransformer(self.model_name)
            self.logger.info(f"Loaded sentence transformer model: {self.model_name}")
            return model
        except Exception as e:
            self.logger.error(f"Failed to load model {self.model_name}: {str(e)}")
            # Try fallback models
            fallback_models = [
                "paraphrase-multilingual-mpnet-base-v2",
                "distiluse-base-multilingual-cased"
            ]
            
            for fallback in fallback_models:
                try:
                    model = SentenceTransformer(fallback)
                    self.logger.info(f"Loaded fallback model: {fallback}")
                    return model
                except Exception as fallback_error:
                    self.logger.warning(f"Fallback model {fallback} also failed: {str(fallback_error)}")
            
            self.logger.error("No sentence transformer models could be loaded")
            return None
    
    def get_embeddings(self, texts: List[str]) -> np.ndarray:
        """
        Get embeddings for a list of texts
        
        Args:
            texts: List of text strings
            
        Returns:
            Numpy array of embeddings
        """
        if self.use_tfidf_fallback:
            return self._get_tfidf_embeddings(texts)
        
        if not self.model:
            raise Exception("Sentence transformer model not available")
        
        try:
            embeddings = self.model.encode(texts, convert_to_numpy=True)
            return embeddings
        except Exception as e:
            self.logger.error(f"Error generating embeddings: {str(e)}")
            raise e
    
    def _get_tfidf_embeddings(self, texts: List[str]) -> np.ndarray:
        """
        Get TF-IDF embeddings for texts (fallback method)
        
        Args:
            texts: List of text strings
            
        Returns:
            Numpy array of TF-IDF embeddings
        """
        try:
            # Fit and transform the texts
            tfidf_matrix = self.tfidf_vectorizer.fit_transform(texts)
            return tfidf_matrix.toarray()
        except Exception as e:
            self.logger.error(f"Error generating TF-IDF embeddings: {str(e)}")
            # Return simple word count vectors as ultimate fallback
            return self._get_simple_embeddings(texts)
    
    def _get_simple_embeddings(self, texts: List[str]) -> np.ndarray:
        """
        Get simple word count embeddings (ultimate fallback)
        
        Args:
            texts: List of text strings
            
        Returns:
            Numpy array of simple embeddings
        """
        # Create a simple vocabulary from all texts
        all_words = set()
        for text in texts:
            words = text.lower().split()
            all_words.update(words)
        
        vocab = list(all_words)
        embeddings = []
        
        for text in texts:
            words = text.lower().split()
            embedding = [words.count(word) for word in vocab]
            embeddings.append(embedding)
        
        return np.array(embeddings)

    def calculate_similarity(self, text1: str, text2: str) -> float:
        """
        Calculate cosine similarity between two texts
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            Cosine similarity score (0-1)
        """
        if not text1 or not text2:
            return 0.0
        
        try:
            embeddings = self.get_embeddings([text1, text2])
            if len(embeddings) < 2:
                return 0.0
            similarity = cosine_similarity([embeddings[0]], [embeddings[1]])[0][0]
            return float(similarity)
        except Exception as e:
            self.logger.error(f"Error calculating similarity: {str(e)}")
            return 0.0
    
    def analyze_transition_similarity(self, transition: Dict[str, Any], article: Dict[str, Any], 
                                   similarity_threshold: float = 0.1) -> Dict[str, Any]:
        """
        Analyze semantic similarity between transition and surrounding paragraphs
        
        Args:
            transition: Transition dictionary
            article: Article dictionary
            similarity_threshold: Minimum difference threshold for cohesion check
            
        Returns:
            Dictionary with similarity scores and analysis
        """
        transition_text = transition.get('text', '')
        para_idx = transition.get('para_idx', 0)
        paragraphs = article.get('paragraphs', [])
        
        results = {
            'transition_text': transition_text,
            'para_idx': para_idx,
            'next_paragraph': '',
            'previous_paragraph': '',
            'similarity_next': 0.0,
            'similarity_prev': 0.0,
            'similarity_difference': 0.0,
            'thematic_cohesion_pass': False,
            'has_context': False
        }
        
        # Get context paragraphs
        if para_idx > 0 and para_idx - 1 < len(paragraphs):
            results['previous_paragraph'] = paragraphs[para_idx - 1]
        
        if para_idx < len(paragraphs):
            results['next_paragraph'] = paragraphs[para_idx]
        
        results['has_context'] = bool(results['previous_paragraph'] or results['next_paragraph'])
        
        if not results['has_context']:
            self.logger.warning(f"No context paragraphs found for transition at para_idx {para_idx}")
            return results
        
        try:
            # Calculate similarity with next paragraph
            if results['next_paragraph']:
                results['similarity_next'] = self.calculate_similarity(
                    transition_text, results['next_paragraph']
                )
            
            # Calculate similarity with previous paragraph
            if results['previous_paragraph']:
                results['similarity_prev'] = self.calculate_similarity(
                    transition_text, results['previous_paragraph']
                )
            
            # Calculate difference (transition should be more similar to next paragraph)
            results['similarity_difference'] = results['similarity_next'] - results['similarity_prev']
            
            # Check thematic cohesion
            results['thematic_cohesion_pass'] = results['similarity_difference'] > similarity_threshold
            
        except Exception as e:
            self.logger.error(f"Error in similarity analysis: {str(e)}")
            results['error'] = str(e)
        
        return results
    
    def analyze_article_flow(self, article: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze the overall semantic flow of an article
        
        Args:
            article: Article dictionary
            
        Returns:
            Flow analysis results
        """
        paragraphs = article.get('paragraphs', [])
        
        if len(paragraphs) < 2:
            return {'error': 'Not enough paragraphs for flow analysis'}
        
        try:
            # Calculate similarities between consecutive paragraphs
            consecutive_similarities = []
            
            for i in range(len(paragraphs) - 1):
                similarity = self.calculate_similarity(paragraphs[i], paragraphs[i + 1])
                consecutive_similarities.append(similarity)
            
            # Overall flow metrics
            avg_similarity = np.mean(consecutive_similarities) if consecutive_similarities else 0
            similarity_variance = np.var(consecutive_similarities) if consecutive_similarities else 0
            min_similarity = min(consecutive_similarities) if consecutive_similarities else 0
            max_similarity = max(consecutive_similarities) if consecutive_similarities else 0
            
            return {
                'consecutive_similarities': consecutive_similarities,
                'average_similarity': float(avg_similarity),
                'similarity_variance': float(similarity_variance),
                'min_similarity': float(min_similarity),
                'max_similarity': float(max_similarity),
                'flow_consistency': 1.0 - similarity_variance  # Lower variance = better consistency
            }
            
        except Exception as e:
            self.logger.error(f"Error in article flow analysis: {str(e)}")
            return {'error': str(e)}
    
    def find_similar_transitions(self, target_transition: str, other_transitions: List[str], 
                               top_k: int = 3) -> List[Dict[str, Any]]:
        """
        Find the most similar transitions to a target transition
        
        Args:
            target_transition: The transition to compare against
            other_transitions: List of other transitions to compare with
            top_k: Number of top similar transitions to return
            
        Returns:
            List of similar transitions with scores
        """
        if not other_transitions:
            return []
        
        try:
            similarities = []
            for i, transition in enumerate(other_transitions):
                similarity = self.calculate_similarity(target_transition, transition)
                similarities.append({
                    'index': i,
                    'text': transition,
                    'similarity': similarity
                })
            
            # Sort by similarity (descending)
            similarities.sort(key=lambda x: x['similarity'], reverse=True)
            
            return similarities[:top_k]
            
        except Exception as e:
            self.logger.error(f"Error finding similar transitions: {str(e)}")
            return []
    
    def batch_similarity_analysis(self, transitions: List[Dict[str, Any]], 
                                articles: List[Dict[str, Any]], 
                                similarity_threshold: float = 0.1) -> List[Dict[str, Any]]:
        """
        Perform batch similarity analysis for multiple transitions
        
        Args:
            transitions: List of transition dictionaries
            articles: List of article dictionaries
            similarity_threshold: Minimum difference threshold
            
        Returns:
            List of similarity analysis results
        """
        results = []
        
        # Create a mapping of article_id to article for quick lookup
        article_map = {article['article_id']: article for article in articles}
        
        for transition in transitions:
            article_id = transition.get('article_id')
            if article_id in article_map:
                article = article_map[article_id]
                analysis = self.analyze_transition_similarity(transition, article, similarity_threshold)
                analysis['transition_id'] = transition.get('index', 0)
                results.append(analysis)
            else:
                self.logger.warning(f"Article {article_id} not found for transition analysis")
        
        return results
    
    def model_available(self) -> bool:
        """Check if the similarity model is available"""
        return self.model is not None
    
    def get_model_info(self) -> Dict[str, str]:
        """Get information about the loaded model"""
        if self.model:
            return {
                'model_name': self.model_name,
                'max_seq_length': str(getattr(self.model, 'max_seq_length', 'Unknown')),
                'status': 'loaded'
            }
        else:
            return {
                'model_name': self.model_name,
                'status': 'not_available'
            }
