import pandas as pd
from collections import Counter, defaultdict
from typing import List, Dict, Any
import json
import logging

class ResultsProcessor:
    """Process and format analysis results"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def create_results_dataframe(self, results: List[Dict[str, Any]]) -> pd.DataFrame:
        """
        Create a comprehensive results DataFrame matching contest requirements
        
        Args:
            results: List of analysis results
            
        Returns:
            Pandas DataFrame with formatted results (contest format)
        """
        try:
            formatted_results = []
            
            for result in results:
                # Contest-required columns: article_id, para_idx, transition_text, 
                # per-rule pass/fail, failure_reason, triggered_rule, similarity_next, similarity_prev
                row = {
                    'article_id': result.get('article_id', ''),
                    'para_idx': result.get('para_idx', 0),
                    'transition_text': result.get('transition_text', ''),
                }
                
                # Per-rule pass/fail
                rule_checks = result.get('rule_checks', {})
                row['word_limit_pass'] = rule_checks.get('word_limit', True)
                row['concluding_placement_pass'] = rule_checks.get('concluding_placement', True)
                
                # Repetition check
                repetition_info = result.get('repetition_info', {})
                repeated_lemmas = repetition_info.get('repeated_lemmas', [])
                row['repetition_pass'] = len(repeated_lemmas) == 0
                
                # Thematic cohesion check
                similarity_scores = result.get('similarity_scores', {})
                row['thematic_cohesion_pass'] = similarity_scores.get('thematic_cohesion_pass', False)
                
                # Overall pass/fail
                row['overall_pass'] = result.get('overall_pass', False)
                
                # Failure reason and triggered rules (contest format)
                failure_reasons = result.get('failure_reasons', [])
                row['failure_reason'] = ' | '.join(failure_reasons) if failure_reasons else ''
                
                triggered_rules = result.get('triggered_rules', [])
                row['triggered_rule'] = ', '.join(triggered_rules) if triggered_rules else ''
                
                # Contest-required similarity scores
                row['similarity_next'] = similarity_scores.get('next_paragraph', 0.0)
                row['similarity_prev'] = similarity_scores.get('previous_paragraph', 0.0)
                
                # Additional useful columns
                row['word_count'] = result.get('word_count', 0)
                row['is_concluding'] = result.get('is_concluding', False)
                row['repeated_lemmas'] = ', '.join(repeated_lemmas) if repeated_lemmas else ''
                row['similarity_difference'] = row['similarity_next'] - row['similarity_prev']
                
                formatted_results.append(row)
            
            df = pd.DataFrame(formatted_results)
            
            # Sort by article_id and para_idx
            if not df.empty:
                df = df.sort_values(['article_id', 'para_idx'])
                df = df.reset_index(drop=True)
            
            return df
            
        except Exception as e:
            self.logger.error(f"Error creating results DataFrame: {str(e)}")
            return pd.DataFrame()
    
    def calculate_summary_stats(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Calculate comprehensive summary statistics
        
        Args:
            results: List of analysis results
            
        Returns:
            Dictionary with summary statistics
        """
        if not results:
            return {
                'total_transitions': 0,
                'compliance_rate': 0,
                'failed_transitions': 0,
                'rule_failures': Counter(),
                'repeated_lemmas': Counter(),
                'similarity_stats': {}
            }
        
        try:
            total_transitions = len(results)
            passed_transitions = sum(1 for r in results if r.get('overall_pass', False))
            failed_transitions = total_transitions - passed_transitions
            compliance_rate = (passed_transitions / total_transitions * 100) if total_transitions > 0 else 0
            
            # Rule failure analysis
            rule_failures = Counter()
            for result in results:
                for rule in result.get('triggered_rules', []):
                    rule_failures[rule] += 1
            
            # Repetition analysis
            all_repeated_lemmas = Counter()
            for result in results:
                repeated_lemmas = result.get('repetition_info', {}).get('repeated_lemmas', [])
                for lemma in repeated_lemmas:
                    all_repeated_lemmas[lemma] += 1
            
            # Similarity statistics
            similarity_next_scores = [r.get('similarity_scores', {}).get('next_paragraph', 0) for r in results]
            similarity_prev_scores = [r.get('similarity_scores', {}).get('previous_paragraph', 0) for r in results]
            
            similarity_stats = {
                'avg_similarity_next': sum(similarity_next_scores) / len(similarity_next_scores) if similarity_next_scores else 0,
                'avg_similarity_prev': sum(similarity_prev_scores) / len(similarity_prev_scores) if similarity_prev_scores else 0,
                'max_similarity_next': max(similarity_next_scores) if similarity_next_scores else 0,
                'min_similarity_next': min(similarity_next_scores) if similarity_next_scores else 0,
                'max_similarity_prev': max(similarity_prev_scores) if similarity_prev_scores else 0,
                'min_similarity_prev': min(similarity_prev_scores) if similarity_prev_scores else 0
            }
            
            # Word count analysis
            word_counts = [r.get('word_count', 0) for r in results]
            word_count_stats = {
                'avg_word_count': sum(word_counts) / len(word_counts) if word_counts else 0,
                'max_word_count': max(word_counts) if word_counts else 0,
                'min_word_count': min(word_counts) if word_counts else 0,
                'over_limit_count': sum(1 for wc in word_counts if wc > 5)
            }
            
            # Failure reason analysis
            failure_reasons = Counter()
            for result in results:
                for reason in result.get('failure_reasons', []):
                    # Extract the main failure type
                    if 'word limit' in reason.lower():
                        failure_reasons['Word Limit Exceeded'] += 1
                    elif 'repetition' in reason.lower() or 'repeated' in reason.lower():
                        failure_reasons['Lemma Repetition'] += 1
                    elif 'cohesion' in reason.lower():
                        failure_reasons['Poor Thematic Cohesion'] += 1
                    elif 'placement' in reason.lower():
                        failure_reasons['Incorrect Placement'] += 1
                    else:
                        failure_reasons['Other'] += 1
            
            return {
                'total_transitions': total_transitions,
                'passed_transitions': passed_transitions,
                'failed_transitions': failed_transitions,
                'compliance_rate': compliance_rate,
                'rule_failures': rule_failures,
                'repeated_lemmas': all_repeated_lemmas,
                'similarity_stats': similarity_stats,
                'word_count_stats': word_count_stats,
                'failure_reasons': failure_reasons
            }
            
        except Exception as e:
            self.logger.error(f"Error calculating summary stats: {str(e)}")
            return {}
    
    def export_to_csv(self, df: pd.DataFrame, filename: str = 'transition_analysis_results.csv') -> str:
        """
        Export results to CSV format
        
        Args:
            df: Results DataFrame
            filename: Output filename
            
        Returns:
            CSV string
        """
        try:
            return df.to_csv(index=False)
        except Exception as e:
            self.logger.error(f"Error exporting to CSV: {str(e)}")
            return ""
    
    def export_to_html(self, df: pd.DataFrame, summary_stats: Dict[str, Any], 
                      filename: str = 'transition_analysis_results.html') -> str:
        """
        Export results to HTML format with summary
        
        Args:
            df: Results DataFrame
            summary_stats: Summary statistics
            filename: Output filename
            
        Returns:
            HTML string
        """
        try:
            html_parts = []
            
            # HTML header
            html_parts.append("""
            <!DOCTYPE html>
            <html>
            <head>
                <title>French News Transition QA Analysis Results</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    .summary { background-color: #f5f5f5; padding: 15px; margin-bottom: 20px; border-radius: 5px; }
                    .metric { display: inline-block; margin: 10px; padding: 10px; background-color: white; border-radius: 3px; }
                    table { border-collapse: collapse; width: 100%; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background-color: #f2f2f2; }
                    .pass { color: green; font-weight: bold; }
                    .fail { color: red; font-weight: bold; }
                </style>
            </head>
            <body>
            <h1>French News Transition QA Analysis Results</h1>
            """)
            
            # Summary section
            html_parts.append('<div class="summary">')
            html_parts.append('<h2>Summary Statistics</h2>')
            html_parts.append(f'<div class="metric">Total Transitions: <strong>{summary_stats.get("total_transitions", 0)}</strong></div>')
            html_parts.append(f'<div class="metric">Compliance Rate: <strong>{summary_stats.get("compliance_rate", 0):.1f}%</strong></div>')
            html_parts.append(f'<div class="metric">Failed Transitions: <strong>{summary_stats.get("failed_transitions", 0)}</strong></div>')
            html_parts.append('</div>')
            
            # Detailed results table
            html_parts.append('<h2>Detailed Results</h2>')
            
            # Customize the DataFrame display for HTML
            df_html = df.copy()
            df_html['overall_pass'] = df_html['overall_pass'].apply(lambda x: '<span class="pass">✓</span>' if x else '<span class="fail">✗</span>')
            
            html_table = df_html.to_html(index=False, escape=False, classes='results-table')
            html_parts.append(html_table)
            
            # Footer
            html_parts.append('</body></html>')
            
            return '\n'.join(html_parts)
            
        except Exception as e:
            self.logger.error(f"Error exporting to HTML: {str(e)}")
            return "<html><body><h1>Error generating HTML report</h1></body></html>"
    
    def create_detailed_report(self, results: List[Dict[str, Any]], 
                             summary_stats: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a comprehensive detailed report
        
        Args:
            results: Analysis results
            summary_stats: Summary statistics
            
        Returns:
            Detailed report dictionary
        """
        try:
            report = {
                'metadata': {
                    'total_articles': len(set(r.get('article_id', '') for r in results)),
                    'total_transitions': len(results),
                    'analysis_timestamp': pd.Timestamp.now().isoformat(),
                    'model_info': 'French NLP + Sentence Transformers'
                },
                'summary': summary_stats,
                'detailed_results': results
            }
            
            # Add article-level analysis
            article_analysis = defaultdict(lambda: {
                'total_transitions': 0,
                'passed_transitions': 0,
                'failed_transitions': 0,
                'compliance_rate': 0,
                'common_issues': []
            })
            
            for result in results:
                article_id = result.get('article_id', '')
                article_analysis[article_id]['total_transitions'] += 1
                
                if result.get('overall_pass', False):
                    article_analysis[article_id]['passed_transitions'] += 1
                else:
                    article_analysis[article_id]['failed_transitions'] += 1
                    article_analysis[article_id]['common_issues'].extend(result.get('triggered_rules', []))
            
            # Calculate article-level compliance rates
            for article_id, stats in article_analysis.items():
                if stats['total_transitions'] > 0:
                    stats['compliance_rate'] = (stats['passed_transitions'] / stats['total_transitions'] * 100)
                stats['common_issues'] = list(Counter(stats['common_issues']).most_common(3))
            
            report['article_analysis'] = dict(article_analysis)
            
            return report
            
        except Exception as e:
            self.logger.error(f"Error creating detailed report: {str(e)}")
            return {}
    
    def export_to_json(self, report: Dict[str, Any], filename: str = 'transition_analysis_report.json') -> str:
        """
        Export comprehensive report to JSON
        
        Args:
            report: Detailed report dictionary
            filename: Output filename
            
        Returns:
            JSON string
        """
        try:
            return json.dumps(report, indent=2, ensure_ascii=False, default=str)
        except Exception as e:
            self.logger.error(f"Error exporting to JSON: {str(e)}")
            return "{}"
