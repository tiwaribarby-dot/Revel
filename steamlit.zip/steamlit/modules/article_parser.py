import re
from typing import List, Dict, Any
import logging

class ArticleParser:
    """Parser for French news articles with transitions"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def parse_articles(self, text: str) -> List[Dict[str, Any]]:
        """
        Parse multiple articles from text input
        
        Args:
            text: Raw text containing one or more articles
            
        Returns:
            List of parsed article dictionaries
        """
        articles = []
        
        # Split text into individual articles (assuming they're separated by multiple newlines or specific markers)
        article_texts = self._split_articles(text)
        
        for i, article_text in enumerate(article_texts):
            try:
                article = self._parse_single_article(article_text, f"article_{i+1}")
                if article:
                    articles.append(article)
            except Exception as e:
                self.logger.error(f"Error parsing article {i+1}: {str(e)}")
                continue
        
        return articles
    
    def _split_articles(self, text: str) -> List[str]:
        """Split text into individual articles"""
        # Clean up the text
        text = text.strip()
        
        # If the text contains multiple "Titre:" entries, split on those
        if text.count("Titre:") > 1:
            articles = re.split(r'\n\s*Titre:', text)
            # Add "Titre:" back to all but the first
            for i in range(1, len(articles)):
                articles[i] = "Titre:" + articles[i]
            return [article.strip() for article in articles if article.strip()]
        else:
            return [text]
    
    def _parse_single_article(self, text: str, article_id: str) -> Dict[str, Any]:
        """
        Parse a single article
        
        Args:
            text: Raw article text
            article_id: Unique identifier for the article
            
        Returns:
            Parsed article dictionary or None if parsing fails
        """
        article = {
            'article_id': article_id,
            'title': '',
            'chapeau': '',
            'content': '',
            'paragraphs': [],
            'transitions': []
        }
        
        try:
            # Extract title
            title_match = re.search(r'Titre:\s*(.+?)(?=\n|$)', text, re.IGNORECASE)
            if title_match:
                article['title'] = title_match.group(1).strip()
            
            # Extract chapeau
            chapeau_match = re.search(r'Chapeau:\s*(.+?)(?=\nArticle:|$)', text, re.IGNORECASE | re.DOTALL)
            if chapeau_match:
                article['chapeau'] = chapeau_match.group(1).strip()
            
            # Extract article content
            content_match = re.search(r'Article:\s*(.+?)(?=\nTransitions générées:|$)', text, re.IGNORECASE | re.DOTALL)
            if content_match:
                article['content'] = content_match.group(1).strip()
                
                # Split content into paragraphs - handle both single line breaks and double line breaks
                # Clean up the content first
                content_lines = article['content'].split('\n')
                paragraphs = []
                current_paragraph = []
                
                for line in content_lines:
                    line = line.strip()
                    if not line:
                        # Empty line - end current paragraph if we have content
                        if current_paragraph:
                            paragraphs.append(' '.join(current_paragraph))
                            current_paragraph = []
                    else:
                        current_paragraph.append(line)
                
                # Add the last paragraph if it exists
                if current_paragraph:
                    paragraphs.append(' '.join(current_paragraph))
                
                article['paragraphs'] = paragraphs
            
            # Extract transitions
            transitions_match = re.search(r'Transitions générées:\s*(.+)', text, re.IGNORECASE | re.DOTALL)
            if transitions_match:
                transitions_text = transitions_match.group(1).strip()
                article['transitions'] = self._parse_transitions(transitions_text, len(article['paragraphs']))
            
            # Validate that we have essential components
            if not article['content'] or not article['transitions']:
                self.logger.warning(f"Article {article_id} missing essential components")
                return None
            
            return article
            
        except Exception as e:
            self.logger.error(f"Error parsing article {article_id}: {str(e)}")
            return None
    
    def _parse_transitions(self, transitions_text: str, num_paragraphs: int) -> List[Dict[str, Any]]:
        """
        Parse transitions from the transitions section
        
        Args:
            transitions_text: Raw transitions text
            num_paragraphs: Number of paragraphs in the article
            
        Returns:
            List of transition dictionaries
        """
        transitions = []
        
        # Pattern to match numbered transitions
        pattern = r'(\d+)\.\s*(.+?)(?=\n\d+\.|$)'
        matches = re.findall(pattern, transitions_text, re.DOTALL)
        
        for i, (num, transition_text) in enumerate(matches):
            transition_text = transition_text.strip()
            
            # Remove any trailing punctuation for analysis
            clean_text = transition_text.rstrip('.,;:!?')
            
            # Determine paragraph index (transitions typically appear between paragraphs)
            # For simplicity, assume transitions appear in order between consecutive paragraphs
            para_idx = i + 1  # Transition appears after paragraph i
            
            # Determine if this is a concluding transition (last transition)
            is_concluding = (i == len(matches) - 1)
            
            transition = {
                'index': int(num),
                'text': transition_text,
                'clean_text': clean_text,
                'para_idx': para_idx,
                'is_concluding': is_concluding,
                'position_in_article': 'final' if is_concluding else 'middle'
            }
            
            transitions.append(transition)
        
        return transitions
    
    def get_paragraph_context(self, article: Dict[str, Any], para_idx: int) -> Dict[str, str]:
        """
        Get the context paragraphs (previous and next) for a given paragraph index
        
        Args:
            article: Parsed article dictionary
            para_idx: Paragraph index
            
        Returns:
            Dictionary with 'previous' and 'next' paragraph texts
        """
        context = {'previous': '', 'next': ''}
        
        paragraphs = article['paragraphs']
        
        if para_idx > 0 and para_idx - 1 < len(paragraphs):
            context['previous'] = paragraphs[para_idx - 1]
        
        if para_idx < len(paragraphs):
            context['next'] = paragraphs[para_idx]
        
        return context
    
    def validate_article_structure(self, article: Dict[str, Any]) -> Dict[str, bool]:
        """
        Validate the structure of a parsed article
        
        Args:
            article: Parsed article dictionary
            
        Returns:
            Dictionary of validation results
        """
        validation = {
            'has_title': bool(article.get('title')),
            'has_chapeau': bool(article.get('chapeau')),
            'has_content': bool(article.get('content')),
            'has_paragraphs': len(article.get('paragraphs', [])) > 0,
            'has_transitions': len(article.get('transitions', [])) > 0,
            'transitions_numbered_correctly': True
        }
        
        # Check if transitions are numbered correctly
        transitions = article.get('transitions', [])
        for i, transition in enumerate(transitions):
            if transition.get('index', 0) != i + 1:
                validation['transitions_numbered_correctly'] = False
                break
        
        return validation
