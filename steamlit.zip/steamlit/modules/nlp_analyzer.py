import spacy
from collections import Counter, defaultdict
from typing import Dict, Any, List, Set
import logging

class NLPAnalyzer:
    """French NLP analyzer for transition analysis"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.nlp = self._load_french_model()
        
    def _load_french_model(self):
        """Load French spaCy model"""
        try:
            # Try to load the medium French model first
            nlp = spacy.load("fr_core_news_md")
            self.logger.info("Loaded fr_core_news_md model")
        except OSError:
            try:
                # Fallback to small model
                nlp = spacy.load("fr_core_news_sm")
                self.logger.info("Loaded fr_core_news_sm model")
            except OSError:
                try:
                    # Last fallback to basic model
                    nlp = spacy.load("fr")
                    self.logger.info("Loaded basic fr model")
                except OSError:
                    self.logger.error("No French spaCy model found. Please install: python -m spacy download fr_core_news_sm")
                    # Create a minimal fallback
                    nlp = None
        
        return nlp
    
    def get_lemmas(self, text: str) -> List[str]:
        """
        Extract lemmas from text
        
        Args:
            text: Input text
            
        Returns:
            List of lemmas
        """
        if not self.nlp:
            # Fallback: return words as-is if no model available
            return text.lower().split()
        
        try:
            doc = self.nlp(text)
            lemmas = []
            
            for token in doc:
                # Skip punctuation, spaces, and stop words
                if not token.is_punct and not token.is_space and not token.is_stop:
                    lemmas.append(token.lemma_.lower())
            
            return lemmas
        except Exception as e:
            self.logger.error(f"Error extracting lemmas: {str(e)}")
            return text.lower().split()
    
    def get_article_lemmas(self, article: Dict[str, Any]) -> Counter:
        """
        Extract all lemmas from an article
        
        Args:
            article: Parsed article dictionary
            
        Returns:
            Counter object with lemma frequencies
        """
        all_text = []
        
        # Combine all text from the article
        if article.get('title'):
            all_text.append(article['title'])
        
        if article.get('chapeau'):
            all_text.append(article['chapeau'])
        
        if article.get('content'):
            all_text.append(article['content'])
        
        # Extract lemmas from combined text
        combined_text = ' '.join(all_text)
        lemmas = self.get_lemmas(combined_text)
        
        return Counter(lemmas)
    
    def detect_repetition(self, transition_text: str, article_lemmas: Counter) -> Dict[str, Any]:
        """
        Detect lemma repetition between transition and article
        
        Args:
            transition_text: The transition text to analyze
            article_lemmas: Counter of lemmas in the full article
            
        Returns:
            Dictionary with repetition information
        """
        transition_lemmas = self.get_lemmas(transition_text)
        repeated_lemmas = []
        repetition_counts = {}
        
        for lemma in transition_lemmas:
            # A lemma is considered repeated if it appears elsewhere in the article
            # (frequency > 1 means it appears in transition + elsewhere)
            if article_lemmas.get(lemma, 0) > 1:
                repeated_lemmas.append(lemma)
                repetition_counts[lemma] = article_lemmas[lemma]
        
        return {
            'repeated_lemmas': repeated_lemmas,
            'repetition_counts': repetition_counts,
            'has_repetition': len(repeated_lemmas) > 0,
            'transition_lemmas': transition_lemmas
        }
    
    def analyze_transition_pos(self, transition_text: str) -> Dict[str, Any]:
        """
        Analyze part-of-speech tags in transition
        
        Args:
            transition_text: Transition text
            
        Returns:
            POS analysis results
        """
        if not self.nlp:
            return {'error': 'NLP model not available'}
        
        try:
            doc = self.nlp(transition_text)
            pos_counts = Counter()
            tokens_info = []
            
            for token in doc:
                if not token.is_punct and not token.is_space:
                    pos_counts[token.pos_] += 1
                    tokens_info.append({
                        'text': token.text,
                        'lemma': token.lemma_,
                        'pos': token.pos_,
                        'tag': token.tag_
                    })
            
            return {
                'pos_distribution': dict(pos_counts),
                'tokens': tokens_info,
                'has_verb': 'VERB' in pos_counts,
                'has_noun': 'NOUN' in pos_counts,
                'has_adjective': 'ADJ' in pos_counts
            }
            
        except Exception as e:
            self.logger.error(f"Error in POS analysis: {str(e)}")
            return {'error': str(e)}
    
    def extract_named_entities(self, text: str) -> List[Dict[str, str]]:
        """
        Extract named entities from text
        
        Args:
            text: Input text
            
        Returns:
            List of named entities
        """
        if not self.nlp:
            return []
        
        try:
            doc = self.nlp(text)
            entities = []
            
            for ent in doc.ents:
                entities.append({
                    'text': ent.text,
                    'label': ent.label_,
                    'description': spacy.explain(ent.label_) or ent.label_
                })
            
            return entities
            
        except Exception as e:
            self.logger.error(f"Error extracting entities: {str(e)}")
            return []
    
    def analyze_article_coherence(self, article: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze overall coherence of the article
        
        Args:
            article: Parsed article dictionary
            
        Returns:
            Coherence analysis results
        """
        paragraphs = article.get('paragraphs', [])
        
        if len(paragraphs) < 2:
            return {'error': 'Not enough paragraphs for coherence analysis'}
        
        # Analyze lemma overlap between consecutive paragraphs
        paragraph_lemmas = []
        for paragraph in paragraphs:
            lemmas = self.get_lemmas(paragraph)
            paragraph_lemmas.append(set(lemmas))
        
        # Calculate overlap between consecutive paragraphs
        overlaps = []
        for i in range(len(paragraph_lemmas) - 1):
            current = paragraph_lemmas[i]
            next_para = paragraph_lemmas[i + 1]
            
            if len(current) > 0 and len(next_para) > 0:
                overlap = len(current.intersection(next_para))
                union = len(current.union(next_para))
                overlap_ratio = overlap / union if union > 0 else 0
                overlaps.append(overlap_ratio)
        
        avg_overlap = sum(overlaps) / len(overlaps) if overlaps else 0
        
        return {
            'paragraph_count': len(paragraphs),
            'avg_lemma_overlap': avg_overlap,
            'paragraph_overlaps': overlaps,
            'coherence_score': avg_overlap  # Simple coherence metric
        }
    
    def get_transition_linguistic_features(self, transition_text: str) -> Dict[str, Any]:
        """
        Extract comprehensive linguistic features from transition
        
        Args:
            transition_text: Transition text
            
        Returns:
            Dictionary of linguistic features
        """
        features = {}
        
        # Basic features
        features['word_count'] = len(transition_text.split())
        features['char_count'] = len(transition_text)
        
        # Lemma analysis
        lemmas = self.get_lemmas(transition_text)
        features['lemma_count'] = len(lemmas)
        features['unique_lemma_count'] = len(set(lemmas))
        
        # POS analysis
        pos_analysis = self.analyze_transition_pos(transition_text)
        features['pos_analysis'] = pos_analysis
        
        # Named entities
        entities = self.extract_named_entities(transition_text)
        features['named_entities'] = entities
        features['has_named_entities'] = len(entities) > 0
        
        # Punctuation analysis
        punctuation_count = sum(1 for char in transition_text if char in '.,;:!?')
        features['punctuation_count'] = punctuation_count
        
        return features
    
    def model_available(self) -> bool:
        """Check if French NLP model is available"""
        return self.nlp is not None
