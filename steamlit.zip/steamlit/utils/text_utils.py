import re
import unicodedata
from typing import List, Dict, Any, Optional
import logging

class TextUtils:
    """Utility functions for text processing and manipulation"""
    
    @staticmethod
    def clean_text(text: str) -> str:
        """
        Clean and normalize text
        
        Args:
            text: Input text
            
        Returns:
            Cleaned text
        """
        if not text:
            return ""
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text.strip())
        
        # Normalize unicode characters
        text = unicodedata.normalize('NFKC', text)
        
        return text
    
    @staticmethod
    def remove_punctuation_for_analysis(text: str) -> str:
        """
        Remove punctuation for analysis while preserving the structure
        
        Args:
            text: Input text
            
        Returns:
            Text without punctuation
        """
        # Remove common punctuation but keep apostrophes in French contractions
        text = re.sub(r'[.,;:!?""()«»\[\]{}]', ' ', text)
        text = re.sub(r'\s+', ' ', text.strip())
        return text
    
    @staticmethod
    def count_words(text: str, method: str = 'simple') -> int:
        """
        Count words in text with different methods
        
        Args:
            text: Input text
            method: Counting method ('simple', 'linguistic')
            
        Returns:
            Word count
        """
        if not text:
            return 0
        
        if method == 'simple':
            return len(text.split())
        elif method == 'linguistic':
            # More sophisticated word counting for French
            # Handle contractions and compound words
            words = re.findall(r"\b[\w']+\b", text.lower())
            return len(words)
        else:
            return len(text.split())
    
    @staticmethod
    def extract_sentences(text: str) -> List[str]:
        """
        Extract sentences from text
        
        Args:
            text: Input text
            
        Returns:
            List of sentences
        """
        # French sentence splitting with common abbreviations
        abbreviations = r'(?:M\.|Mme\.|Dr\.|Prof\.|etc\.|cf\.|vs\.|St\.|Ste\.)'
        
        # Split on sentence-ending punctuation, but not after abbreviations
        sentences = re.split(r'(?<!' + abbreviations + r')\s*[.!?]+\s*', text)
        
        # Clean up sentences
        sentences = [s.strip() for s in sentences if s.strip()]
        
        return sentences
    
    @staticmethod
    def is_valid_french_text(text: str, min_length: int = 3) -> bool:
        """
        Check if text appears to be valid French text
        
        Args:
            text: Input text
            min_length: Minimum length for valid text
            
        Returns:
            True if text appears valid
        """
        if not text or len(text.strip()) < min_length:
            return False
        
        # Check for French-specific patterns
        french_indicators = [
            r'\b(le|la|les|un|une|des|du|de|et|à|en|dans|sur|avec|pour|par)\b',
            r'\b(qui|que|dont|où|quand|comment|pourquoi)\b',
            r'\b(être|avoir|faire|dire|aller|voir|savoir|pouvoir|vouloir)\b'
        ]
        
        for pattern in french_indicators:
            if re.search(pattern, text.lower()):
                return True
        
        # Check for French accented characters
        if re.search(r'[àâäéèêëîïôöùûüÿç]', text.lower()):
            return True
        
        return True  # Default to true for basic validation
    
    @staticmethod
    def normalize_transition_text(text: str) -> str:
        """
        Normalize transition text for analysis
        
        Args:
            text: Transition text
            
        Returns:
            Normalized text
        """
        # Remove leading/trailing punctuation commonly used in transitions
        text = text.strip('.,;:!?')
        
        # Normalize case (first letter uppercase, rest lowercase)
        if text:
            text = text[0].upper() + text[1:].lower() if len(text) > 1 else text.upper()
        
        return text.strip()
    
    @staticmethod
    def extract_key_phrases(text: str, min_length: int = 2) -> List[str]:
        """
        Extract key phrases from text (simple implementation)
        
        Args:
            text: Input text
            min_length: Minimum phrase length in words
            
        Returns:
            List of key phrases
        """
        # Simple n-gram extraction
        words = re.findall(r'\b\w+\b', text.lower())
        phrases = []
        
        for n in range(min_length, min(len(words) + 1, 4)):  # Up to 3-grams
            for i in range(len(words) - n + 1):
                phrase = ' '.join(words[i:i+n])
                phrases.append(phrase)
        
        return list(set(phrases))
    
    @staticmethod
    def calculate_text_complexity(text: str) -> Dict[str, Any]:
        """
        Calculate basic text complexity metrics
        
        Args:
            text: Input text
            
        Returns:
            Dictionary with complexity metrics
        """
        if not text:
            return {'error': 'Empty text'}
        
        words = text.split()
        sentences = TextUtils.extract_sentences(text)
        
        # Basic metrics
        word_count = len(words)
        sentence_count = len(sentences)
        char_count = len(text)
        
        # Average metrics
        avg_words_per_sentence = word_count / sentence_count if sentence_count > 0 else 0
        avg_chars_per_word = char_count / word_count if word_count > 0 else 0
        
        # Complexity indicators
        long_words = sum(1 for word in words if len(word) > 6)
        long_word_ratio = long_words / word_count if word_count > 0 else 0
        
        return {
            'word_count': word_count,
            'sentence_count': sentence_count,
            'char_count': char_count,
            'avg_words_per_sentence': round(avg_words_per_sentence, 2),
            'avg_chars_per_word': round(avg_chars_per_word, 2),
            'long_word_ratio': round(long_word_ratio, 3),
            'complexity_score': round(avg_words_per_sentence * long_word_ratio, 2)
        }
    
    @staticmethod
    def find_text_patterns(text: str) -> Dict[str, List[str]]:
        """
        Find common patterns in text
        
        Args:
            text: Input text
            
        Returns:
            Dictionary with found patterns
        """
        patterns = {}
        
        # Find dates (various French formats)
        date_patterns = [
            r'\b\d{1,2}\s+(?:janvier|février|mars|avril|mai|juin|juillet|août|septembre|octobre|novembre|décembre)\s+\d{4}\b',
            r'\b\d{1,2}/\d{1,2}/\d{4}\b',
            r'\b\d{1,2}-\d{1,2}-\d{4}\b'
        ]
        patterns['dates'] = []
        for pattern in date_patterns:
            patterns['dates'].extend(re.findall(pattern, text, re.IGNORECASE))
        
        # Find times
        patterns['times'] = re.findall(r'\b\d{1,2}h\d{0,2}\b|\b\d{1,2}:\d{2}\b', text)
        
        # Find numbers
        patterns['numbers'] = re.findall(r'\b\d+(?:[.,]\d+)?\b', text)
        
        # Find email addresses
        patterns['emails'] = re.findall(r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', text)
        
        # Find phone numbers (French format)
        patterns['phones'] = re.findall(r'\b0[1-9](?:\s?\d{2}){4}\b', text)
        
        # Find URLs
        patterns['urls'] = re.findall(r'https?://(?:[-\w.])+(?:\.[a-zA-Z]{2,4})+(?:/[^\s]*)?', text)
        
        return patterns
    
    @staticmethod
    def truncate_text(text: str, max_length: int = 100, suffix: str = "...") -> str:
        """
        Truncate text to a maximum length
        
        Args:
            text: Input text
            max_length: Maximum length
            suffix: Suffix to add when truncating
            
        Returns:
            Truncated text
        """
        if not text or len(text) <= max_length:
            return text
        
        # Try to truncate at word boundary
        truncated = text[:max_length - len(suffix)]
        last_space = truncated.rfind(' ')
        
        if last_space > max_length * 0.7:  # If we can find a reasonable word boundary
            truncated = truncated[:last_space]
        
        return truncated + suffix
    
    @staticmethod
    def highlight_text(text: str, terms: List[str], 
                      highlight_start: str = "<mark>", 
                      highlight_end: str = "</mark>") -> str:
        """
        Highlight specific terms in text
        
        Args:
            text: Input text
            terms: Terms to highlight
            highlight_start: Opening highlight tag
            highlight_end: Closing highlight tag
            
        Returns:
            Text with highlighted terms
        """
        if not terms:
            return text
        
        highlighted_text = text
        
        for term in terms:
            if term.strip():
                # Case-insensitive replacement
                pattern = re.compile(re.escape(term), re.IGNORECASE)
                highlighted_text = pattern.sub(
                    f"{highlight_start}{term}{highlight_end}", 
                    highlighted_text
                )
        
        return highlighted_text
