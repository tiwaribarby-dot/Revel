import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from collections import Counter
import os
import tempfile
import io

from modules.article_parser import ArticleParser
from modules.rule_validator import RuleValidator
from modules.nlp_analyzer import NLPAnalyzer
from modules.similarity_analyzer import SimilarityAnalyzer
from modules.results_processor import ResultsProcessor

# Page configuration
st.set_page_config(
    page_title="French News Transition QA Tool",
    page_icon="📰",
    layout="wide"
)

# Initialize session state
if 'results_df' not in st.session_state:
    st.session_state.results_df = None
if 'summary_stats' not in st.session_state:
    st.session_state.summary_stats = None

def initialize_components():
    """Initialize all analysis components"""
    try:
        parser = ArticleParser()
        rule_validator = RuleValidator()
        nlp_analyzer = NLPAnalyzer()
        similarity_analyzer = SimilarityAnalyzer()
        results_processor = ResultsProcessor()
        return parser, rule_validator, nlp_analyzer, similarity_analyzer, results_processor
    except Exception as e:
        st.error(f"Error initializing components: {str(e)}")
        return None, None, None, None, None

def process_articles(articles_text, similarity_threshold=0.1):
    """Process articles and return results"""
    parser, rule_validator, nlp_analyzer, similarity_analyzer, results_processor = initialize_components()
    
    if None in [parser, rule_validator, nlp_analyzer, similarity_analyzer, results_processor]:
        return None, None
    
    try:
        # Parse articles
        with st.spinner("Parsing articles..."):
            articles = parser.parse_articles(articles_text)
        
        if not articles:
            st.error("No valid articles found in the input text.")
            return None, None
        
        st.success(f"Found {len(articles)} articles to process")
        
        all_results = []
        progress_bar = st.progress(0)
        
        for idx, article in enumerate(articles):
            # Update progress
            progress_bar.progress((idx + 1) / len(articles))
            
            # Process each article
            article_results = process_single_article(
                article, rule_validator, nlp_analyzer, 
                similarity_analyzer, similarity_threshold
            )
            all_results.extend(article_results)
        
        progress_bar.empty()
        
        # Process results
        results_df = results_processor.create_results_dataframe(all_results)
        summary_stats = results_processor.calculate_summary_stats(all_results)
        
        return results_df, summary_stats
        
    except Exception as e:
        st.error(f"Error processing articles: {str(e)}")
        return None, None

def process_single_article(article, rule_validator, nlp_analyzer, similarity_analyzer, similarity_threshold):
    """Process a single article and return results"""
    results = []
    article_id = article['article_id']
    
    # Get article lemmas for repetition detection
    article_lemmas = nlp_analyzer.get_article_lemmas(article)
    
    for i, transition in enumerate(article['transitions']):
        result = {
            'article_id': article_id,
            'para_idx': transition['para_idx'],
            'transition_text': transition['text'],
            'word_count': len(transition['text'].split()),
            'is_concluding': transition['is_concluding'],
            'rule_checks': {},
            'repetition_info': {},
            'similarity_scores': {},
            'overall_pass': True,
            'failure_reasons': [],
            'triggered_rules': []
        }
        
        # Rule validation
        rule_checks = rule_validator.validate_transition(transition)
        result['rule_checks'] = rule_checks
        
        # Check if rules passed
        for rule, passed in rule_checks.items():
            if not passed:
                result['overall_pass'] = False
                result['triggered_rules'].append(rule)
                if rule == 'word_limit':
                    result['failure_reasons'].append(f"Exceeds 5-word limit ({result['word_count']} words)")
                elif rule == 'concluding_placement':
                    result['failure_reasons'].append("Non-concluding transition in final position")
        
        # Repetition detection
        repetition_info = nlp_analyzer.detect_repetition(transition['text'], article_lemmas)
        result['repetition_info'] = repetition_info
        
        if repetition_info['repeated_lemmas']:
            result['failure_reasons'].append(f"Repeated lemmas: {', '.join(repetition_info['repeated_lemmas'])}")
        
        # Semantic similarity analysis
        try:
            similarity_scores = similarity_analyzer.analyze_transition_similarity(
                transition, article, similarity_threshold
            )
            result['similarity_scores'] = similarity_scores
            
            # Check thematic cohesion (contest requirement: transition ↔ next should be higher than transition ↔ previous)
            sim_next = similarity_scores.get('next_paragraph', 0.0)
            sim_prev = similarity_scores.get('previous_paragraph', 0.0)
            
            # Update similarity scores with thematic cohesion result
            if sim_next > sim_prev + similarity_threshold:
                similarity_scores['thematic_cohesion_pass'] = True
            else:
                similarity_scores['thematic_cohesion_pass'] = False
                result['overall_pass'] = False
                result['triggered_rules'].append('thematic_cohesion')
                result['failure_reasons'].append(f"Poor thematic cohesion: sim_next ({sim_next:.3f}) ≤ sim_prev ({sim_prev:.3f})")
                
        except Exception as e:
            st.warning(f"Similarity analysis failed for transition: {transition['text'][:50]}...")
            result['similarity_scores'] = {'next_paragraph': 0.0, 'previous_paragraph': 0.0, 'thematic_cohesion_pass': False, 'error': str(e)}
        
        results.append(result)
    
    return results

def display_results(results_df, summary_stats):
    """Display results in the Streamlit interface"""
    if results_df is None or summary_stats is None:
        return
    
    st.header("📊 Analysis Results")
    
    # Summary statistics
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Total Transitions", summary_stats['total_transitions'])
    
    with col2:
        compliance_rate = summary_stats['compliance_rate']
        st.metric("Compliance Rate", f"{compliance_rate:.1f}%")
    
    with col3:
        st.metric("Failed Transitions", summary_stats['failed_transitions'])
    
    with col4:
        st.metric("Articles Processed", len(results_df['article_id'].unique()))
    
    # Detailed results table
    st.subheader("Detailed Results")
    
    # Add filters
    col1, col2 = st.columns(2)
    with col1:
        show_failed_only = st.checkbox("Show failed transitions only")
    with col2:
        selected_articles = st.multiselect(
            "Filter by Article ID",
            options=results_df['article_id'].unique(),
            default=results_df['article_id'].unique()
        )
    
    # Filter data
    filtered_df = results_df[results_df['article_id'].isin(selected_articles)]
    if show_failed_only:
        filtered_df = filtered_df[~filtered_df['overall_pass']]
    
    # Display table with contest-required columns
    display_columns = [
        'article_id', 'para_idx', 'transition_text', 'word_limit_pass', 
        'concluding_placement_pass', 'repetition_pass', 'thematic_cohesion_pass',
        'overall_pass', 'failure_reason', 'triggered_rule',
        'similarity_next', 'similarity_prev', 'word_count'
    ]
    
    # Ensure all columns exist in the dataframe
    available_columns = [col for col in display_columns if col in filtered_df.columns]
    
    st.dataframe(
        filtered_df[available_columns],
        use_container_width=True,
        column_config={
            'article_id': st.column_config.TextColumn('Article ID', width='small'),
            'para_idx': st.column_config.NumberColumn('Para Index', width='small'),
            'transition_text': st.column_config.TextColumn('Transition Text', width='large'),
            'word_limit_pass': st.column_config.CheckboxColumn('Word Limit ≤5', width='small'),
            'concluding_placement_pass': st.column_config.CheckboxColumn('Placement OK', width='small'),
            'repetition_pass': st.column_config.CheckboxColumn('No Repetition', width='small'),
            'thematic_cohesion_pass': st.column_config.CheckboxColumn('Cohesion OK', width='small'),
            'overall_pass': st.column_config.CheckboxColumn('Overall Pass', width='small'),
            'failure_reason': st.column_config.TextColumn('Failure Reason', width='medium'),
            'triggered_rule': st.column_config.TextColumn('Triggered Rule', width='medium'),
            'similarity_next': st.column_config.NumberColumn('Sim Next', format='%.3f', width='small'),
            'similarity_prev': st.column_config.NumberColumn('Sim Prev', format='%.3f', width='small'),
            'word_count': st.column_config.NumberColumn('Words', width='small'),
        }
    )
    
    # Visualizations
    st.subheader("📈 Analysis Visualizations")
    
    # Failure reasons chart
    if summary_stats['failure_reasons']:
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**Most Common Failure Types**")
            failure_df = pd.DataFrame(list(summary_stats['failure_reasons'].items()), 
                                    columns=['Failure Type', 'Count'])
            fig = px.bar(failure_df, x='Failure Type', y='Count', 
                        title="Distribution of Failure Types")
            fig.update_xaxes(tickangle=45)
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            st.write("**Most Repeated Lemmas**")
            if summary_stats['repeated_lemmas']:
                lemma_df = pd.DataFrame(list(summary_stats['repeated_lemmas'].most_common(10)), 
                                      columns=['Lemma', 'Count'])
                fig = px.bar(lemma_df, x='Lemma', y='Count', 
                            title="Top 10 Most Repeated Lemmas")
                fig.update_xaxes(tickangle=45)
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("No repeated lemmas found")
    
    # Similarity distribution
    if 'similarity_next' in filtered_df.columns and 'similarity_prev' in filtered_df.columns:
        st.write("**Similarity Score Distribution**")
        fig = go.Figure()
        fig.add_trace(go.Histogram(x=filtered_df['similarity_next'], name='Next Paragraph', opacity=0.7))
        fig.add_trace(go.Histogram(x=filtered_df['similarity_prev'], name='Previous Paragraph', opacity=0.7))
        fig.update_layout(title='Distribution of Similarity Scores', barmode='overlay')
        st.plotly_chart(fig, use_container_width=True)

def export_results(results_df):
    """Provide export functionality"""
    if results_df is None:
        return
    
    st.subheader("📥 Export Results")
    
    col1, col2 = st.columns(2)
    
    with col1:
        # CSV export
        csv_buffer = io.StringIO()
        results_df.to_csv(csv_buffer, index=False)
        st.download_button(
            label="📄 Download as CSV",
            data=csv_buffer.getvalue(),
            file_name="transition_analysis_results.csv",
            mime="text/csv"
        )
    
    with col2:
        # HTML export
        html_buffer = io.StringIO()
        results_df.to_html(html_buffer, index=False, escape=False)
        st.download_button(
            label="🌐 Download as HTML",
            data=html_buffer.getvalue(),
            file_name="transition_analysis_results.html",
            mime="text/html"
        )

def main():
    """Main application"""
    st.title("📰 French News Transition QA Tool")
    st.markdown("**Contest Prototype:** Quality assurance tool for French news transition phrases")
    
    st.info("""
    **Objective:** Evaluate French transition phrases between news paragraphs:
    - ✅ **Rule Checks:** Word count ≤5, concluding placement
    - ✅ **Repetition Detection:** French lemma analysis  
    - ✅ **Thematic Cohesion:** Transition ↔ next paragraph similarity > transition ↔ previous paragraph
    - ✅ **Explainable Results:** Clear pass/fail with detailed failure reasons
    """)
    
    # Sidebar configuration
    st.sidebar.header("⚙️ Configuration")
    similarity_threshold = st.sidebar.slider(
        "Similarity Threshold",
        min_value=0.0,
        max_value=1.0,
        value=0.1,
        step=0.05,
        help="Minimum difference between transition→next and transition→previous similarity"
    )
    
    # File upload
    st.header("📁 Input Data")
    
    # Option 1: File upload
    uploaded_file = st.file_uploader(
        "Upload article file(s)",
        type=['txt'],
        accept_multiple_files=False,
        help="Upload a text file containing French news articles with transitions"
    )
    
    # Option 2: Text area input
    st.markdown("**Or paste article text directly:**")
    text_input = st.text_area(
        "Article Text",
        height=200,
        placeholder="Paste your French news articles here..."
    )
    
    # Option 3: Load sample data
    if st.button("📋 Load Sample Data"):
        try:
            with open('data/sample_articles.txt', 'r', encoding='utf-8') as f:
                text_input = f.read()
            st.success("Sample data loaded!")
            st.rerun()
        except FileNotFoundError:
            st.warning("Sample data file not found. Please upload your own data.")
    
    # Process data
    articles_text = None
    if uploaded_file:
        articles_text = uploaded_file.read().decode('utf-8')
        st.success(f"File uploaded: {uploaded_file.name}")
    elif text_input:
        articles_text = text_input
    
    if articles_text and st.button("🚀 Analyze Transitions", type="primary"):
        with st.spinner("Processing articles..."):
            results_df, summary_stats = process_articles(articles_text, similarity_threshold)
            
            if results_df is not None:
                st.session_state.results_df = results_df
                st.session_state.summary_stats = summary_stats
                st.success("Analysis completed!")
                st.rerun()
    
    # Display results if available
    if st.session_state.results_df is not None:
        display_results(st.session_state.results_df, st.session_state.summary_stats)
        export_results(st.session_state.results_df)
    
    # Help section
    with st.expander("ℹ️ How to use this tool"):
        st.markdown("""
        ### Input Format
        The tool expects French news articles in this format:
        ```
        Titre: [Article title]
        Chapeau: [Article summary]
        Article: [Article content with multiple paragraphs]
        Transitions générées:
        1. [First transition]
        2. [Second transition]
        ...
        ```
        
        ### Analysis Features
        - **Rule Validation**: Checks 5-word limit and concluding placement rules
        - **Repetition Detection**: Identifies repeated lemmas across the article
        - **Semantic Analysis**: Evaluates thematic cohesion between transitions and adjacent paragraphs
        - **Comprehensive Reporting**: Detailed results with explanations for failures
        
        ### Output
        - Results table with pass/fail status and detailed explanations
        - Summary statistics and visualizations
        - Export functionality (CSV/HTML)
        """)

if __name__ == "__main__":
    main()
